# CMSC848F  Assignment - 1

## Student Details

|Name|Hritvik Choudhari|
|:---|:---|
|UID|119208793|
|Directory ID|hac|
|Email ID|hac@umd.edu

## Webpage

Note: The webpage file can be found in `webpage/hac.html`

## Running the Code

All of the code results are produced using google colab platform. Please use the same for similar results.

Navigate to the ```hac_assignment1``` folder after unzipping the it.

Mount the folder on google drive

Open `hac_assignment1.ipynb` notebook in google colab paste the address of the ```hac_assignment1``` directory in the first cell.

```
from google.colab import drive

drive.mount('/content/drive', force_remount=True)

<!-- Enter your directory address here -->
FOLDERNAME =  
```

Then, run the other cells that will download the required dependencies.

## Running Questions:

The questions and the appropriate commands are provided in the cells. Run through the cells and the results will be generated in the ```Results``` directory.